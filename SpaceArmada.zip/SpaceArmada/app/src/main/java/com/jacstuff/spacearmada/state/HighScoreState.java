package com.jacstuff.spacearmada.state;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.List;

import com.jacstuff.spacearmada.controls.TouchPoint;

/**
 * Created by john on 11/04/18.
 */

public class HighScoreState implements State {

    public void update(){}

    @Override
    public void draw(Canvas canvas, Paint paint) {

    }

    public void handleTouchPoints(List<TouchPoint> touchPoints){

    }

    public void destroy(){

    }

    public void onPause(){

    }
    public void onResume(){

    }

}
