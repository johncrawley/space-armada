package com.jacstuff.spacearmada.actors.spawners;

import java.util.List;

import com.jacstuff.spacearmada.actors.background.Star;

/**
 * Created by John on 07/10/2017.
 * Creates new stars for the background.
 *
 */

public class StarSpawner {

    public void spawn(List<Star> stars){

    }
}
