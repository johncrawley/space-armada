package com.jacstuff.spacearmada.managers;

import android.content.Context;
import android.graphics.drawable.Drawable;

/**
 * Created by John on 13/09/2017.
 */

public interface DrawableLoader {
    Drawable getDrawable(int id);
}
