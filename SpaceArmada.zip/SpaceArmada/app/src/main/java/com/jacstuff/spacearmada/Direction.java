package com.jacstuff.spacearmada;

/**
 * Created by John on 29/08/2017.
 */

public enum Direction {

    UP,DOWN,LEFT,RIGHT,UP_LEFT,UP_RIGHT,DOWN_LEFT,DOWN_RIGHT,NONE;
}
