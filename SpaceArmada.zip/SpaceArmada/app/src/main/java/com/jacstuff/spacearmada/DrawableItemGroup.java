package com.jacstuff.spacearmada;

import java.util.Collection;
import java.util.List;

public interface DrawableItemGroup {
    List<? extends DrawableItem> getDrawableItems();
}
