package com.jacstuff.spacearmada.actors.ships;

import com.jacstuff.spacearmada.Direction;

/**
 * Created by John on 29/08/2017.
 */

public interface Spaceship {
    void update();
}
