package com.jacstuff.spacearmada.actors.background;

import com.jacstuff.spacearmada.actors.AbstractActor;

/**
 * Created by John on 07/10/2017.
 */

public class Star extends AbstractActor {
}
