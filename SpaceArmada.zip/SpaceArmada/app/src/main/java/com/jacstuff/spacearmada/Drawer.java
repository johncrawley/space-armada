package com.jacstuff.spacearmada;

public interface Drawer {
    void register(DrawableItemGroup dig);
    void draw();
}
