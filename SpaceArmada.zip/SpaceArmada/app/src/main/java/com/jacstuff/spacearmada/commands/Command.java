package com.jacstuff.spacearmada.commands;

/**
 * Created by John on 29/08/2017.
 */

public interface Command {
    void invoke();
    void release();
}
